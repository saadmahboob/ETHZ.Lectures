import tensorflow as tf
import numpy as np
from tensorflow.python.ops import rnn

class TextRNN(object):
    """
    A CNN for text classification.
    Uses an embedding layer, followed by a convolutional, max-pooling and softmax layer.
    """
    def __init__(
      self, sequence_length, num_classes, vocab_size,
      embedding_size, cell_size = 128, num_layers = 1):
      
        # TODO: Placeholders for input, output and dropout
        self.input_x = ...
        self.input_y = ...
        self.dropout_keep_prob = ...

        # TODO: self.pretrained_embeddings is a matrix which is a lookup table - for every word in the vocabulary
        # it contains a low dimensional word vector representation
        self.pretrained_embeddings = ...

        # TODO: This is the *dynamic* shape of the tensor
        self.batch_size = ...

        # TODO: Define our RNN cell
        single_cell = ...
        
        # Possibly multi layer
        cell = single_cell
        if num_layers > 1:
            # TODO: Create here a multi-RNN cell
            cell = ...

        # Embedding layer 
        with tf.device('/cpu:0'), tf.name_scope("embedding"):
            # Input of shape [batch_size, sequence_length, embedding_size]
            self.embedded_tokens = tf.nn.embedding_lookup(self.pretrained_embeddings, self.input_x)
            
        
        # TODO: Prepare the input (hint: use tf.unstack)
        # the tensorflow rnn module requires sequences of [batch_size, input_dim] tensors
        input_seq = ...
        
        # TODO: Define the RNN given the cell and the inputs (hint: use tf.nn.static_rnn)
        # We do not need the outputs at every layer, just the final encoder state
        _, encoder_state = ...
        
        # Add dropout
        with tf.name_scope("dropout"):
            encoder_state_drop = tf.nn.dropout(encoder_state, self.dropout_keep_prob)

        # TODO: Final scores and predictions
        with tf.name_scope("output"):
            W = tf.get_variable(
                "W",
                shape=[cell_size * num_layers, num_classes],
                initializer=tf.contrib.layers.xavier_initializer())
            b = tf.Variable(tf.constant(0.1, shape=[num_classes]), name="b")
            self.scores = ...
            self.predictions = ...

        # TODO: Define Mean cross-entropy loss using  tf.nn.sparse_softmax_cross_entropy_with_logits
        with tf.name_scope("loss"):
            self.loss = ...

        # TODO: Define Mean Accuracy (hint: use  tf.equal and tf.argmax)
        with tf.name_scope("accuracy"):
            self.accuracy = ...
