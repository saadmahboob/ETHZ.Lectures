import tensorflow as tf
import numpy as np


class TextCNN(object):
    """
    A CNN for text classification.
    Uses an embedding layer, followed by a convolutional, max-pooling and softmax layer.

    Input parameters:
    	sequence_length: the length of each sentence. All sentences are padded to have the same length.
	num_classes: number of output classes. In this example: positive vs. negative.
	vocab_size: vocabulary size. Used to define the shape of the embedding layer [vocab_size, embedding_size]
	embedding_size: embedding size/dimensionality.
	filter_sizes: list defining the number of words that will be covered by a convolutional filter, e.g [3,4,5] are filters that will slide over 3, 4, and 5 words respectively.
	num_filters: number of filters per filter_size.
    """
    def __init__(
      self, sequence_length, num_classes, vocab_size,
      embedding_size, filter_sizes, num_filters, l2_reg_lambda=0.0):

        # Placeholders for input, output and dropout
        self.input_x = ...
        self.input_y = ...
        self.dropout_keep_prob = ...

        # self.pretrained_embeddings is a matrix which is a lookup table - for every word in the vocabulary
        # it contains a low dimensional word vector representation
        self.pretrained_embeddings = ...

        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)

        # Embedding layer
        with tf.device('/cpu:0'), tf.name_scope("embedding"):
            # embedding_lookup is the operation which does the actual embedding i.e. it replaces each word (represented
            # as the index of the word in the vocabulary) with its corresponding embedding from the lookup matrix
            # self.embedded_tokens will be a 3-dim tensor of shape [None, sequence_length, embedding_size] where None
            # will depend on the batch size
            self.embedded_tokens = tf.nn.embedding_lookup(self.pretrained_embeddings, self.input_x)

            # conv2d expects a 4-dim tensor of size [batch size, width, height, channels]. self.embedded_tokens doesn't
            # contain the dimension for the channel so we expand the tensor to have one more dimension manually
            self.embedded_tokens_expanded = tf.expand_dims(self.embedded_tokens, -1)

        # Create a convolution + maxpool layer for each filter size. Note that we use filters of different sizes, i.e. each filter varies on the no. of words it covers.
	# We iterate over each filter size, create a layer for each of them and then we append the pooled feature maps into a list.
        pooled_outputs = []
        for _, filter_size in enumerate(filter_sizes):
            with tf.name_scope("conv-maxpool-%s" % filter_size):
                # Convolution Layer
                # the filter should be a 4-D tensor of shape [filter_height, filter_width, in_channels, out_channels]
                # filter_height represents how many words the filter cover
                # filter_width is the same as the embedding size
                # in_channels is 1, and out_channels is the num_filters
                filter_shape = [...]
                W = tf.Variable(tf.truncated_normal(filter_shape, stddev=0.1), name="W")
                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                # TODO: Apply convolutions
                # For NLP tasks the stride is typically [1, 1, 1, 1] and in_channels=1
                conv = ...

                # TODO: Use a relu non-linearity before max-pooling
                relu = ...

                # TODO: Maxpooling over the outputs
                pooled = ...


                pooled_outputs.append(pooled)

        # TODO: Combine all the pooled features
        self.h_pool_flat = ...

        # TODO: add dropout
        with tf.name_scope("dropout"):
            self.h_drop = ...

        # TODO: get (unnormalized) scores and predictions (optional: add L2 regularization of soft-max weights)
        with tf.name_scope("output"):

            self.scores = ...
            self.predictions = ...

        # TODO: Define Mean cross-entropy loss using  tf.nn.sparse_softmax_cross_entropy_with_logits
        with tf.name_scope("loss"):
            self.loss = ...

        # TODO: Define Accuracy (hint: use  tf.equal and tf.argmax)
        with tf.name_scope("accuracy"):
            self.accuracy = ...
