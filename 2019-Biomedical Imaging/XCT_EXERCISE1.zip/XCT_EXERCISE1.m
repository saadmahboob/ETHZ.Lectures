%=========================================================================
%                                                                     
%	TITLE: 
%       XCT - EXERCISE 1
%								
%	DESCRIPTION:						
%       COMPUTE PROJECTIONS OF ANALYTICAL PHANTOM 
%
%	INPUT:								
%       NONE	
%
%	OUTPUT:							
%       DISPLAY
%			
%	VERSION HISTORY:						
%	    150816SK INITIAL VERSION
%	    191020SK UPDATE
%
%=========================================================================

%=========================================================================
%	M A I N  F U N C T I O N
%=========================================================================
function [] = XCT_EXERCISE1()

    clear all; close all; 
    
    
    % --------------------------------------------------------------------
    % Display title
    % -------------------------------------------------------------------- 
    fprintf ( '-----------------------------------------\n' );  
    fprintf ( ' BIOMEDICAL IMAGING - XCT-EXERCISE #1\n' );  
    fprintf ( '-----------------------------------------\n' );  
    
  
    % --------------------------------------------------------------------
    % Set imaging parameters
    % --------------------------------------------------------------------
    matrix      = 256;                      % image matrix  [1pixel = 1mm]
    ua          = 50;                       % anode voltage [keV]
    
    
    % --------------------------------------------------------------------
    % TASK 1.1 (begin)
    % --------------------------------------------------------------------
    % Set density 
    % (see: Table 2 in www.nist.gov/pml/data/xraycoef/)
    % --------------------------------------------------------------------
    
    % TASK 1.1 EDIT HERE
    rho_blood       = 1.000;                % density blood    [g/cm3]
    rho_bone        = 1.000;                % density bone     [g/cm3]
    rho_lung        = 1.000;                % density lung/air [g/cm3]
    rho_muscle      = 1.000;                % density muscle   [g/cm3]
    
     
    % --------------------------------------------------------------------
    % Set X-ray mass attenuation coefficients for 50 and 150 keV
    % (see: Table 4 in www.nist.gov/pml/data/xraycoef/)
    % --------------------------------------------------------------------
    
    % TASK 1.1 EDIT HERE
    mac_blood(1)    = 1.000;                % blood @  50 keV   [cm2/g]
    mac_blood(2)    = 1.000;                % blood @ 150 keV   [cm2/g]
    
    mac_bone(1)     = 1.000;                % bone @  50 keV    [cm2/g]
    mac_bone(2)     = 1.000;                % bone @ 150 keV    [cm2/g]
    
    mac_lung(1)     = 1.000;                % lung @  50 keV    [cm2/g]
    mac_lung(2)     = 1.000;                % lung @ 150 keV    [cm2/g]
    
    mac_muscle(1)   = 1.000;                % muscle @  50 keV  [cm2/g]
    mac_muscle(2)   = 1.000;                % muscle @ 150 keV  [cm2/g]
    
    
    % --------------------------------------------------------------------
    % Calculate linear attenuation coefficients
    % --------------------------------------------------------------------
    
    % TASK 1.1 EDIT HERE
    mue_blood       = 0.0;  
    mue_bone        = 0.0;  
    mue_lung        = 0.0;  
    mue_muscle      = 0.0;  
    
    idx = 1; if ua==150 idx = 2; end
   
    
    % --------------------------------------------------------------------
    % Define test phantom using ellipses with [x0 y0 a b phi mue]
    %
    %       x0,y0   - center point [cm] (+x -> left-right, +y -> bottom-up)
    %       a,b     - half axes [cm]
    %       theta   - rotation angle relative to x-axis [deg]
    %       mue     - linear attenuation coefficient [1/cm]
    % --------------------------------------------------------------------
    
    % TASK 1.1 EDIT HERE
    phantom.ellipse = [-50 0 20 20 0 mue_muscle(idx)];     
    
    
    % --------------------------------------------------------------------
    % Compute and display discrete phantom 
    % --------------------------------------------------------------------
    [x,y] = meshgrid(-fix(matrix/2):+fix(matrix/2));
   
    phantom.discrete = CalcDiscretePhantom(x,y,phantom,ua);
  
    DisplayData(phantom.discrete,[1,4,1]); title('Discrete phantom'); 
    
    
    % --------------------------------------------------------------------
    % Display profile of mue(x)
    % --------------------------------------------------------------------
    DisplayData(phantom.discrete(fix(matrix/2),:)',[1,4,2]); 
    title('Phantom (profile)'); xlabel('x'); ylabel('mue(x)');
    
    
    % --------------------------------------------------------------------
    % Display column-wise sum of mue(x)
    % --------------------------------------------------------------------
    
    % TASK 1.1 FILL IN HERE
    
    title('Phantom (projection)'); xlabel('x'); ylabel('mue(x)');
    
  
    % --------------------------------------------------------------------
    % Compute and display projection
    % --------------------------------------------------------------------
    [r,phi] = meshgrid(-fix(matrix/2):+fix(matrix/2),[0]);  
        
    phantom.projection = CalcLineIntegrals(r,phi,phantom,ua);
    
    DisplayData(phantom.projection',[1,4,4]); 
    title('Projection'); xlabel('r'); ylabel('P(r))'); 
    
    waitforbuttonpress;                                     % pause here
   
   
    % --------------------------------------------------------------------
    % TASK 1.3 (begin)
    % --------------------------------------------------------------------
    % Define thorax phantom using ellipses with [x0 y0 a b phi mue]
    %
    %       x0,y0   - center point [cm] (+x -> left-right, +y -> bottom-up)
    %       a,b     - half axes [cm]
    %       theta   - rotation angle relative to x-axis [deg]
    %       mue     - linear attenuation coefficient [1/cm]
    % --------------------------------------------------------------------
    
    % TASK 1.3 EDIT HERE
    phantom.ellipse = [   0   0   90  80  0   mue_muscle(idx);  % thorax
                          0   0   0   0   0   0;                % lung
                          0   0   0   0   0   0;                % left arm muscle
                          0   0   0   0   0   0;                % left arm bone
                          0   0   0   0   0   0;                % right arm muscle
                          0   0   0   0   0   0;                % right arm bone
                          0   0   0   0   0   0;                % aorta 
                          0   0   0   0   0   0];               % heart
    
     
    % --------------------------------------------------------------------
    % Compute phantom, projection and display
    % --------------------------------------------------------------------
    [x,y]   = meshgrid(-fix(matrix/2):+fix(matrix/2));
    [r,phi] = meshgrid(-fix(matrix/2):+fix(matrix/2),[0]);  
   
    phantom.discrete    = CalcDiscretePhantom(x,y,phantom,ua);
    phantom.projection  = CalcLineIntegrals(r,phi,phantom,ua);

    phantom_no_contrast = phantom.discrete;
    project_no_contrast = phantom.projection;
    
    % TASK 1.3 UNCOMMENT HERE
    %DisplayData(phantom.discrete,[1,4,1]); 
    %title('Phantom (w/o contrast agent)'); 
                    
    %DisplayData(phantom.projection',[1,4,2]); 
    %title('Projection (w/o contrast agent)'); xlabel('r'); ylabel('P(r))'); 
   
    
    % --------------------------------------------------------------------
    % Recompute phantom and projections (blood with contrast agent)
    % --------------------------------------------------------------------
    
    % TASK 1.3 EDIT HERE
    phantom.ellipse(7,6) = 0;   % mue of iodine contrast agent in blood              
    
    phantom.discrete    = CalcDiscretePhantom(x,y,phantom,ua);
    phantom.projection  = CalcLineIntegrals(r,phi,phantom,ua);
    
   
    % --------------------------------------------------------------------
    % Subtract images, projections and display (with contrast agent)
    % --------------------------------------------------------------------
    
    % TASK 1.3 FILL IN HERE
   
    % TASK 1.3 UNCOMMENT HERE
    %DisplayData(phantom_dsa,[1,4,3]); 
    %title('Phantom (DSA)'); 
                    
    %DisplayData(project_dsa',[1,4,4]); 
    %title('Projection (DSA)'); xlabel('r'); ylabel('P(r))');
          
end


%=========================================================================
function [image] = CalcDiscretePhantom(x,y,phantom,ua)
    
    image = zeros(size(x));
    
    for k = 1:length(phantom.ellipse(:,1))
        
        theta   = phantom.ellipse(k,5)*pi/180;
        
        X0      = [x(:)'-phantom.ellipse(k,1);y(:)'-phantom.ellipse(k,2)];
        D       = [1/phantom.ellipse(k,3) 0;0 1/phantom.ellipse(k,4)];
        Q       = [cos(theta) sin(theta); -sin(theta) cos(theta)];
         
        % ----------------------------------------------------------------
        % Find inside of ellipse given by X0,D,Q
        % ----------------------------------------------------------------
        equ = sum((D*Q*X0).^2);
        i = find(equ <= 1);
         
        % ----------------------------------------------------------------
        % Assign linear attenuation coefficients
        % ----------------------------------------------------------------
        image(i) = image(i)+phantom.ellipse(k,6);
        
    end
end


%=========================================================================
function [projection] = CalcLineIntegrals(r,phi,phantom,ua)
    
    projection  = zeros(size(r));
    phi         = phi/180*pi;
    
    sinphi  = sin(phi(:)); 
    cosphi  = cos(phi(:));
    
    rx      = r(:).*cosphi; 
    ry      = r(:).*sinphi;
    
    for k=1:length(phantom.ellipse(:,1))
        
        x0      = phantom.ellipse(k,1); y0 = phantom.ellipse(k,2);
        a       = phantom.ellipse(k,3); b  = phantom.ellipse(k,4);
        
        theta   = phantom.ellipse(k,5)*pi/180; 
        mue     = phantom.ellipse(k,6);
        
        r0      = [rx-x0,ry-y0]';
        
        DQ      = [cos(theta)/a sin(theta)/a; -sin(theta)/b cos(theta)/b];
        DQphi   = DQ*[sinphi,-cosphi]'; 
        DQr0    = DQ*r0;
        
        A       = sum(DQphi.^2); 
        B       = 2*sum(DQphi.*DQr0);
        C       = sum(DQr0.^2)-1; 
        equ     = B.^2-4*A.*C;
        
        i       = find(equ>0);
        
        sp      = 0.5*(-B(i)+sqrt(equ(i)))./A(i);
        sq      = 0.5*(-B(i)-sqrt(equ(i)))./A(i);
        
        
        % ----------------------------------------------------------------
        % TASK 1.2 (begin)
        % ----------------------------------------------------------------
        
        % TASK 1.2 FILL IN/EDIT HERE
        
        proj    = 0;
        
        % ----------------------------------------------------------------
        % TASK 1.2 (end)
        % ----------------------------------------------------------------
         
        projection(i) = projection(i)+proj;
    end
    
    projection = reshape(projection,size(r));
end


%=========================================================================
%=========================================================================